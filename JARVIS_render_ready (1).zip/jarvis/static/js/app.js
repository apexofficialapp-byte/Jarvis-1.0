(() => {
  const $ = (s) => document.querySelector(s);
  const hero = $("#hero"), chat = $("#chat"), messages = $("#messages");
  const prompt = $("#prompt"), chatPrompt = $("#chatPrompt");
  const send = $("#sendBtn"), chatSend = $("#chatSend");
  const count = $("#count"), orb = document.querySelector(".orb-wrap");

  let busy = false;

  function escapeHtml(value) {
    return value.replace(/[&<>"']/g, c => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[c]));
  }

  // Small, dependency-free Markdown-ish renderer. HTML is escaped first.
  function renderText(text) {
    let html = escapeHtml(text);
    html = html.replace(/```([\s\S]*?)```/g, (_, code) =>
      `<pre><code>${code.trim()}</code></pre>`);
    html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
    html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/^\s*[-*]\s+(.+)$/gm, "• $1");
    html = html.replace(/\n/g, "<br>");
    return html;
  }

  function addMessage(role, text, thinking = false) {
    const row = document.createElement("div");
    row.className = `message ${role}`;
    if (thinking) {
      row.innerHTML = `<div class="avatar"></div><div class="bubble thinking">Thinking <span class="dots"><i></i><i></i><i></i></span></div>`;
    } else {
      row.innerHTML = role === "assistant"
        ? `<div class="avatar"></div><div><div class="bubble">${renderText(text)}</div><div class="actions"><button class="copy">Copy</button></div></div>`
        : `<div class="bubble">${renderText(text)}</div>`;
      if (role === "assistant") {
        row.querySelector(".copy").addEventListener("click", async (e) => {
          try {
            await navigator.clipboard.writeText(text);
            e.target.textContent = "Copied";
            setTimeout(() => e.target.textContent = "Copy", 1300);
          } catch {
            e.target.textContent = "Copy failed";
            setTimeout(() => e.target.textContent = "Copy", 1300);
          }
        });
      }
    }
    messages.appendChild(row);
    row.scrollIntoView({behavior:"smooth", block:"end"});
    return row;
  }

  function setBusy(state) {
    busy = state;
    send.disabled = state; chatSend.disabled = state;
    orb?.classList.toggle("thinking-state", state);
  }

  async function submitMessage(text) {
    text = text.trim();
    if (!text || busy) return;

    if (hero.classList.contains("hidden") === false) {
      hero.classList.add("hidden");
      chat.classList.remove("hidden");
    }

    addMessage("user", text);
    const thinking = addMessage("assistant", "", true);
    setBusy(true);
    prompt.value = ""; chatPrompt.value = ""; updateCount();

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({message: text})
      });
      const data = await res.json().catch(() => ({}));
      thinking.remove();
      if (!res.ok || !data.success) throw new Error(data.error || "JARVIS could not complete this request.");
      addMessage("assistant", data.response);
    } catch (err) {
      thinking.remove();
      addMessage("assistant", `I couldn't complete that request.\n\n${err.message}`);
    } finally {
      setBusy(false);
      chatPrompt.focus();
    }
  }

  function updateCount() {
    count.textContent = `${prompt.value.length.toLocaleString()} / 12,000`;
  }

  prompt.addEventListener("input", updateCount);
  send.addEventListener("click", () => submitMessage(prompt.value));
  chatSend.addEventListener("click", () => submitMessage(chatPrompt.value));

  [prompt, chatPrompt].forEach(el => el.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submitMessage(el.value);
    }
  }));

  document.querySelectorAll(".chips button").forEach(btn => {
    btn.addEventListener("click", () => {
      prompt.value = btn.dataset.prompt;
      updateCount();
      prompt.focus();
    });
  });

  $("#launchBtn").addEventListener("click", () => prompt.focus());

  $("#newChat").addEventListener("click", () => {
    messages.innerHTML = "";
    chat.classList.add("hidden");
    hero.classList.remove("hidden");
    prompt.focus();
  });

  updateCount();
})();
