import logging
import time
from pathlib import Path

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from .browser_manager import BrowserManager
from .config import AutomationConfig
from .selectors import build_selector_set

logger = logging.getLogger("jarvis.automation")


class AIProvider:
    def generate(self, prompt, request_id=None):
        raise NotImplementedError

    def health(self):
        return {"status": "ok"}


class BrowserAutomationProvider(AIProvider):
    """
    Generic adapter for a user-authorized AI web interface.

    The target site and selectors are intentionally configurable. This avoids
    baking assumptions about a particular provider into JARVIS.
    """

    def __init__(self, config: AutomationConfig):
        self.config = config
        self.selectors = build_selector_set(config)
        self.browser = BrowserManager(config)

    @classmethod
    def from_environment(cls):
        return cls(AutomationConfig.from_environment())

    def health(self):
        configured = bool(self.config.target_url and self.selectors.message)
        return {
            "status": "ok" if configured else "degraded",
            "automation_configured": configured,
            "target_configured": bool(self.config.target_url),
            "response_selector_configured": bool(self.selectors.response),
        }

    def generate(self, prompt, request_id=None):
        if not self.config.target_url:
            raise RuntimeError(
                "AI_TARGET_URL is not configured. Set it to an AI web interface "
                "for which you have legitimate access."
            )

        page = None
        started = time.monotonic()
        try:
            page = self.browser.new_page()
            logger.info("automation started", extra={"request_id": request_id})
            page.goto(
                self.config.target_url,
                wait_until="domcontentloaded",
                timeout=self.config.navigation_timeout_ms,
            )

            if self.selectors.composer_ready:
                page.locator(self.selectors.composer_ready).wait_for(
                    state="visible",
                    timeout=self.config.navigation_timeout_ms,
                )

            composer = page.locator(self.selectors.message).first
            composer.wait_for(state="visible", timeout=self.config.navigation_timeout_ms)
            composer.fill(prompt)

            before = self._response_snapshot(page)

            send = page.locator(self.selectors.send).first
            send.wait_for(state="visible", timeout=self.config.navigation_timeout_ms)
            send.click()

            response = self._wait_for_response(page, before)
            elapsed = time.monotonic() - started
            logger.info(
                "automation completed duration=%.2fs",
                elapsed,
                extra={"request_id": request_id},
            )
            return response

        except PlaywrightTimeoutError as exc:
            raise TimeoutError("The configured AI web interface timed out.") from exc
        except Exception as exc:
            logger.exception(
                "automation error",
                extra={"request_id": request_id},
            )
            # One controlled retry after a browser/context failure.
            try:
                self.browser.restart()
            except Exception:
                logger.exception("browser restart failed", extra={"request_id": request_id})
            raise RuntimeError("Browser automation failed.") from exc
        finally:
            if page:
                try:
                    page.close()
                except Exception:
                    pass

    def _response_snapshot(self, page):
        if not self.selectors.response:
            return ""
        try:
            return page.locator(self.selectors.response).all_inner_texts()[-1:]
        except Exception:
            return []

    def _wait_for_response(self, page, before):
        deadline = time.monotonic() + self.config.request_timeout_ms / 1000
        last_text = ""
        stable_since = None

        if not self.selectors.response:
            raise RuntimeError(
                "RESPONSE_SELECTOR is not configured. Set a selector that identifies "
                "the assistant response element on the authorized target page."
            )

        locator = page.locator(self.selectors.response)

        while time.monotonic() < deadline:
            try:
                texts = locator.all_inner_texts()
                if texts:
                    candidate = texts[-1].strip()
                    if candidate and candidate not in {"Thinking…", "Thinking...", "Loading..."}:
                        if candidate != last_text:
                            last_text = candidate
                            stable_since = time.monotonic()
                        elif stable_since and (
                            time.monotonic() - stable_since
                            >= self.config.response_settle_ms / 1000
                        ):
                            return candidate[: self.config.max_response_chars]
            except Exception:
                pass
            time.sleep(0.25)

        raise TimeoutError("No stable assistant response was detected before timeout.")

    def close(self):
        self.browser.close()
