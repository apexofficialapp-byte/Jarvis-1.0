import logging
import threading
from pathlib import Path

from playwright.sync_api import BrowserContext, Playwright, sync_playwright

from .config import AutomationConfig

logger = logging.getLogger("jarvis.browser")


class BrowserManager:
    """Owns one persistent Playwright context and recreates it after failures."""

    def __init__(self, config: AutomationConfig):
        self.config = config
        self._lock = threading.RLock()
        self._playwright: Playwright | None = None
        self._context: BrowserContext | None = None

    def start(self):
        with self._lock:
            if self._context:
                return self._context

            Path(self.config.profile_path).mkdir(parents=True, exist_ok=True)
            self._playwright = sync_playwright().start()
            launch_args = {
                "headless": self.config.headless,
                "args": ["--disable-dev-shm-usage", "--no-sandbox"],
            }
            if self.config.browser_channel:
                launch_args["channel"] = self.config.browser_channel

            self._context = self._playwright.chromium.launch_persistent_context(
                user_data_dir=self.config.profile_path,
                **launch_args,
            )
            self._context.set_default_timeout(self.config.navigation_timeout_ms)
            return self._context

    def new_page(self):
        context = self.start()
        page = context.new_page()
        page.set_default_timeout(self.config.navigation_timeout_ms)
        return page

    def restart(self):
        with self._lock:
            self.close()
            return self.start()

    def close(self):
        with self._lock:
            try:
                if self._context:
                    self._context.close()
            finally:
                self._context = None
                if self._playwright:
                    self._playwright.stop()
                self._playwright = None

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc, tb):
        self.close()
