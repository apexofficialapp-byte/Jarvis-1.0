from dataclasses import dataclass


@dataclass(frozen=True)
class SelectorSet:
    message: str
    send: str
    response: str
    composer_ready: str


def build_selector_set(config):
    return SelectorSet(
        message=config.message_selector,
        send=config.send_selector,
        response=config.response_selector,
        composer_ready=config.composer_ready_selector,
    )
