import os
from dataclasses import dataclass


@dataclass(frozen=True)
class AutomationConfig:
    target_url: str
    profile_path: str
    headless: bool
    request_timeout_ms: int
    navigation_timeout_ms: int
    response_settle_ms: int
    browser_channel: str | None
    message_selector: str
    send_selector: str
    response_selector: str
    composer_ready_selector: str
    max_response_chars: int

    @classmethod
    def from_environment(cls):
        return cls(
            target_url=os.getenv("AI_TARGET_URL", "").strip(),
            profile_path=os.getenv("BROWSER_PROFILE_PATH", "./.browser-profile"),
            headless=os.getenv("HEADLESS", "true").lower() in {"1", "true", "yes", "on"},
            request_timeout_ms=int(os.getenv("REQUEST_TIMEOUT", "120")) * 1000,
            navigation_timeout_ms=int(os.getenv("NAVIGATION_TIMEOUT", "30")) * 1000,
            response_settle_ms=int(os.getenv("RESPONSE_SETTLE_MS", "1200")),
            browser_channel=os.getenv("BROWSER_CHANNEL") or None,
            message_selector=os.getenv("MESSAGE_SELECTOR", "textarea"),
            send_selector=os.getenv("SEND_SELECTOR", 'button[type="submit"]'),
            response_selector=os.getenv("RESPONSE_SELECTOR", ""),
            composer_ready_selector=os.getenv("COMPOSER_READY_SELECTOR", ""),
            max_response_chars=int(os.getenv("MAX_RESPONSE_CHARS", "50000")),
        )
