# JARVIS

JARVIS is a premium Flask web application whose frontend is branded as JARVIS and whose AI integration is isolated behind a Playwright browser-automation adapter.

The application does **not** require an AI-provider API key. It is designed for an AI web interface that you are legitimately authorized to use. It does not bypass login, CAPTCHA, anti-bot controls, rate limits, or other security mechanisms.

## Architecture

Browser UI → Flask `/api/chat` → `ChatService` → `BrowserAutomationProvider` → `BrowserManager` → authorized AI web interface.

The provider is deliberately generic. Target URL and selectors are environment variables because web interfaces change and each authorized integration has different DOM structure.

## Project tree

```text
jarvis/
├── app.py
├── requirements.txt
├── render.yaml
├── README.md
├── .env.example
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
├── automation/
│   ├── __init__.py
│   ├── config.py
│   ├── browser_manager.py
│   ├── selectors.py
│   └── provider.py
├── services/
│   ├── __init__.py
│   └── chat_service.py
└── tests/
    └── test_app.py
```

## Local installation

Python 3.11+ is recommended.

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Then:

```bash
pip install -r requirements.txt
python -m playwright install chromium
```

If your operating system requires Playwright browser dependencies, use:

```bash
python -m playwright install --with-deps chromium
```

## Configure the authorized session

Copy:

```text
.env.example → .env
```

Set:

```text
AI_TARGET_URL=https://your-authorized-ai-web-interface.example/
MESSAGE_SELECTOR=...
SEND_SELECTOR=...
RESPONSE_SELECTOR=...
```

The selectors must describe the actual interface you are authorized to automate.

For a login-protected service, authenticate through a legitimate browser session. Do not put passwords, cookies, access tokens, or session files into Git.

### Important Render limitation

Render services have ephemeral filesystems unless you add persistent storage through the platform's supported mechanisms. A browser profile under `/tmp` will not reliably preserve login state across redeploys/restarts. If the target requires an interactive login, perform that setup only through an authorized workflow and use storage/configuration appropriate to the service and deployment environment. Never automate around authentication.

## Run locally

```bash
python app.py
```

Open:

```text
http://localhost:10000
```

For production-like local serving:

```bash
gunicorn --workers 1 --threads 4 --timeout 180 --bind 0.0.0.0:10000 app:app
```

## Test

```bash
pytest -q
```

Tests use a fake provider so they do not contact an external AI website.

## Render deployment

The included `render.yaml` installs Chromium during the build:

```text
pip install -r requirements.txt
python -m playwright install --with-deps chromium
```

The service starts with:

```text
gunicorn --workers 1 --threads 4 --timeout 180 --bind 0.0.0.0:$PORT app:app
```

The app binds to `0.0.0.0` and reads Render's `PORT`.

Set the following Render environment variables:

- `AI_TARGET_URL`
- `MESSAGE_SELECTOR`
- `SEND_SELECTOR`
- `RESPONSE_SELECTOR`
- optionally `COMPOSER_READY_SELECTOR`
- `HEADLESS=true`
- `REQUEST_TIMEOUT=120`
- `MAX_CONCURRENT_REQUESTS=2`

Do not add secrets to source control.

## Selector maintenance

Only `automation/` needs to know the target page. If the target DOM changes, update the environment selectors or the provider implementation rather than mixing target-specific selectors into Flask or frontend code.

A reliable response selector should identify the assistant's response content, not the entire conversation. If the target uses streaming, the provider waits until the selected response text stops changing for the configured settle period.

## Security

JARVIS:

- validates JSON and prompt size;
- returns friendly errors instead of tracebacks;
- sets common security headers;
- escapes assistant text before client rendering;
- never executes returned HTML or JavaScript;
- does not log credentials, cookies, or authorization tokens;
- limits concurrent browser jobs;
- uses a configurable timeout.

Basic request rate limiting should be added at the reverse-proxy/platform layer for a public production deployment. The current application deliberately keeps infrastructure small and database-free.

## Operational notes

Playwright is resource-intensive. A single Gunicorn worker is intentional for the initial Render deployment because a persistent browser context should not be multiplied unnecessarily. `MAX_CONCURRENT_REQUESTS=2` provides an application-level guard.

For a larger deployment, use a dedicated job/worker architecture and external persistent storage where appropriate. Multi-instance persistent chat history is not implemented because the initial product intentionally requires no database.

## Provider compliance

Use browser automation only where it is permitted. JARVIS does not:

- bypass CAPTCHA;
- bypass authentication;
- defeat anti-bot systems;
- bypass rate limits;
- access private/protected data without authorization;
- attempt to conceal prohibited automation.

If a provider does not permit this type of automation, use a permitted integration instead.
