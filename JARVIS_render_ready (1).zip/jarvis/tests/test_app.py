import pytest
from app import app


class FakeProvider:
    def health(self):
        return {"status": "ok"}

    def generate(self, prompt, request_id=None):
        return f"REAL-MOCK: {prompt}"


@pytest.fixture()
def client(monkeypatch):
    from app import chat_service
    monkeypatch.setattr(chat_service, "provider", FakeProvider())
    app.config.update(TESTING=True)
    with app.test_client() as client:
        yield client


def test_home(client):
    assert client.get("/").status_code == 200


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json["status"] == "ok"


def test_requires_json(client):
    response = client.post("/api/chat", data="hello")
    assert response.status_code == 415


def test_empty_prompt(client):
    response = client.post("/api/chat", json={"message": "   "})
    assert response.status_code == 400


def test_non_string_prompt(client):
    response = client.post("/api/chat", json={"message": 123})
    assert response.status_code == 400


def test_chat(client):
    response = client.post("/api/chat", json={"message": "hello"})
    assert response.status_code == 200
    assert response.json["success"] is True
    assert "hello" in response.json["response"]
