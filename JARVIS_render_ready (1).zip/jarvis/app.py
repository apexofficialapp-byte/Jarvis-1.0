import logging
import os
import uuid
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from werkzeug.middleware.proxy_fix import ProxyFix

from services.chat_service import ChatService

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s request_id=%(request_id)s %(message)s",
)
logger = logging.getLogger("jarvis")

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config.update(
    MAX_CONTENT_LENGTH=int(os.getenv("MAX_REQUEST_BYTES", "65536")),
    JSON_SORT_KEYS=False,
)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

chat_service = ChatService.from_environment()


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "font-src 'self'; "
        "frame-ancestors 'none';"
    )
    return response


@app.before_request
def attach_request_id():
    request.request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/health")
def health():
    status = chat_service.health()
    code = 200 if status["status"] == "ok" else 503
    return jsonify(status), code


@app.post("/api/chat")
def chat():
    if not request.is_json:
        return jsonify(success=False, error="Request must use JSON."), 415

    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return jsonify(success=False, error="Invalid JSON request."), 400

    message = body.get("message")
    if not isinstance(message, str):
        return jsonify(success=False, error="The message must be text."), 400

    message = message.strip()
    max_chars = chat_service.max_prompt_chars
    if not message:
        return jsonify(success=False, error="Please enter a message."), 400
    if len(message) > max_chars:
        return jsonify(
            success=False,
            error=f"Please keep your message under {max_chars:,} characters.",
        ), 413

    logger.info(
        "request received",
        extra={"request_id": request.request_id},
    )

    try:
        response = chat_service.generate(message, request.request_id)
        return jsonify(success=True, response=response), 200
    except TimeoutError:
        logger.warning("automation timeout", extra={"request_id": request.request_id})
        return jsonify(
            success=False,
            error="The AI service took too long to respond. Please try again.",
        ), 504
    except RuntimeError as exc:
        logger.error(
            "automation failure: %s",
            exc,
            extra={"request_id": request.request_id},
        )
        return jsonify(
            success=False,
            error="JARVIS could not complete this request.",
        ), 502
    except Exception:
        logger.exception("unexpected server error", extra={"request_id": request.request_id})
        return jsonify(
            success=False,
            error="JARVIS is temporarily unavailable. Please try again.",
        ), 500


@app.errorhandler(413)
def too_large(_error):
    return jsonify(success=False, error="Request is too large."), 413


@app.errorhandler(429)
def rate_limited(_error):
    return jsonify(success=False, error="Too many requests. Please wait and try again."), 429


@app.errorhandler(404)
def not_found(_error):
    if request.path.startswith("/api/"):
        return jsonify(success=False, error="Endpoint not found."), 404
    return render_template("index.html"), 404


def main():
    port = int(os.getenv("PORT", "10000"))
    host = os.getenv("HOST", "0.0.0.0")
    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    main()
