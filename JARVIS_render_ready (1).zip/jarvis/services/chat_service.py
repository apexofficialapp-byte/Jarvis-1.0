import logging
import os
import threading
import time

from automation.provider import BrowserAutomationProvider

logger = logging.getLogger("jarvis.chat")


class ChatService:
    def __init__(self, provider, max_concurrent_requests=2, max_prompt_chars=12000):
        self.provider = provider
        self.max_prompt_chars = max_prompt_chars
        self._semaphore = threading.BoundedSemaphore(max_concurrent_requests)

    @classmethod
    def from_environment(cls):
        limit = max(1, int(os.getenv("MAX_CONCURRENT_REQUESTS", "2")))
        max_chars = max(100, int(os.getenv("MAX_PROMPT_CHARS", "12000")))
        return cls(
            BrowserAutomationProvider.from_environment(),
            max_concurrent_requests=limit,
            max_prompt_chars=max_chars,
        )

    def generate(self, prompt, request_id):
        acquired = self._semaphore.acquire(timeout=5)
        if not acquired:
            raise RuntimeError("JARVIS is busy processing other requests.")

        started = time.monotonic()
        try:
            logger.info(
                "processing started",
                extra={"request_id": request_id},
            )
            result = self.provider.generate(prompt, request_id=request_id)
            duration = time.monotonic() - started
            logger.info(
                "response received duration=%.2fs",
                duration,
                extra={"request_id": request_id},
            )
            return result
        finally:
            self._semaphore.release()

    def health(self):
        return self.provider.health()
